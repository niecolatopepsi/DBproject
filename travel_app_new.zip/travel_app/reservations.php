<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT trips.name, trips.description, trips.price, reservations.seats, reservations.reservation_date 
                        FROM reservations 
                        JOIN trips ON reservations.trip_id = trips.id 
                        WHERE reservations.user_id = ?");
$stmt->execute([$user_id]);
$reservations = $stmt->fetchAll();

include 'views/reservations.php';
?>
