<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Travel App</h1>
        <p><a href="login.php">Login</a> or <a href="register.php">Register</a></p>
    </div>
</body>
</html>
