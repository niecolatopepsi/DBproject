<!DOCTYPE html>
<html>
<head>
    <title>Edit trips</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
    <h1>Edit Trip</h1>
    <form action="edit_trip.php?trip_id=<?php echo $trip['id']; ?>" method="POST">
        <label>Name</label>
        <input type="text" name="name" value="<?php echo $trip['name']; ?>" required>
        <label>Description</label>
        <textarea name="description" required><?php echo $trip['description']; ?></textarea>
        <label>Price</label>
        <input type="text" name="price" value="<?php echo $trip['price']; ?>" required>
        <label>Available Seats</label>
        <input type="number" name="available_seats" value="<?php echo $trip['available_seats']; ?>" required>
        <label>City</label>
        <input type="text" name="city" value="<?php echo $trip['city']; ?>" required>
        <label>Country</label>
        <input type="text" name="country" value="<?php echo $trip['country']; ?>" required>
        <label>Start Date</label>
        <input type="date" name="start_date" value="<?php echo $trip['start_date']; ?>" required>
        <label>End Date</label>
        <input type="date" name="end_date" value="<?php echo $trip['end_date']; ?>" required>
        <button type="submit">Update Trip</button>
        </form>
        <a href="trips.php">Back to Trips</a>
</body>
</html>
