<!DOCTYPE html>
<html>
<head>
    <title>Search Trips</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Search Trips</h1>
    <form action="search_trip.php" method="POST">
        <label>City</label>
        <input type="text" name="search_city">
        <label>Country</label>
        <input type="text" name="search_country">
        <button type="submit">Search</button>
    </form>
    <?php if ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
        <ul>
            <?php if (!empty($trips)): ?>
                <?php foreach ($trips as $trip): ?>
                    <li>
                        <h2><?php echo $trip['name']; ?></h2>
                        <p><?php echo $trip['description']; ?></p>
                        <p>Price: <?php echo $trip['price']; ?> USD</p>
                        <p>Available Seats: <?php echo $trip['available_seats']; ?></p>
                        <p>City: <?php echo $trip['city']; ?></p>
                        <p>Country: <?php echo $trip['country']; ?></p>
                        <p>Start Date: <?php echo $trip['start_date']; ?></p>
                        <p>End Date: <?php echo $trip['end_date']; ?></p>
                        <a href="book_trip.php?trip_id=<?php echo $trip['id']; ?>">Book Now</a>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No trips found matching your criteria.</p>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
    <a href="trips.php">Back to Trips</a>
    <a href="logout.php">Logout</a>
</body>
</html>
