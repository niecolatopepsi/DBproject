<!DOCTYPE html>
<html>
<head>
    <title>Book trips</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
    <h1>Book Trip</h1>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form action="book_trip.php" method="POST">
        <input type="hidden" name="trip_id" value="<?php echo $trip['id']; ?>">
        <label>Trip Name</label>
        <p><?php echo $trip['name']; ?></p>
        <label>Description</label>
        <p><?php echo $trip['description']; ?></p>
        <label>Price</label>
        <p><?php echo $trip['price']; ?> USD</p>
        <label>Available Seats</label>
        <p><?php echo $trip['available_seats']; ?></p>
        <label>Number of Seats</label>
        <input type="number" name="seats" min="1" max="<?php echo $trip['available_seats']; ?>" required>
        <button type="submit">Book Now</button>
    </form>
    <a href="trips.php">Back to Trips</a>
</body>
</html>
