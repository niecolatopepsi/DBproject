<!DOCTYPE html>
<html>
<head>
    <title>My Reservations</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
    <h1>My Reservations</h1>
    <?php if (isset($_SESSION['message'])): ?>
        <p style="color: green;"><?php echo $_SESSION['message']; ?></p>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    <ul>
        <?php foreach ($reservations as $reservation): ?>
            <li>
                <h2><?php echo $reservation['name']; ?></h2>
                <p><?php echo $reservation['description']; ?></p>
                <p>Price: <?php echo $reservation['price']; ?> USD</p>
                <p>Seats: <?php echo $reservation['seats']; ?></p>
                <p>Reservation Date: <?php echo $reservation['reservation_date']; ?></p>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="trips.php">Back to Trips</a>
    <a href="logout.php">Logout</a>
</body>
</html>
