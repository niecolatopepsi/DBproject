<!DOCTYPE html>
<html>
<head>
    <title>Create Trip</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Create New Trip</h1>
        <form action="create_trip.php" method="POST">
            <label>Name</label>
            <input type="text" name="name" required>
            <label>Description</label>
            <textarea name="description" required></textarea>
            <label>Price</label>
            <input type="number" name="price" required>
            <label>Available Seats</label>
            <input type="number" name="available_seats" required>
            <label>City</label>
            <input type="text" name="city" required>
            <label>Country</label>
            <input type="text" name="country" required>
            <label>Start Date</label>
            <input type="date" name="start_date" required>
            <label>End Date</label>
            <input type="date" name="end_date" required>
            <button type="submit">Create</button>
        </form>
        <a href="trips.php">Back to Trips</a>
    </div>
</body>
</html>
