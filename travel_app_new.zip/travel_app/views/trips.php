<!DOCTYPE html>
<html>
<head>
    <title>Trips</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Trips</h1>
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message"><?php echo $_SESSION['message']; ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <form method="GET" action="trips.php">
            <label for="search_city">Search by City:</label>
            <input type="text" id="search_city" name="search_city" value="<?php echo htmlspecialchars($searchCity); ?>">
            
            <label for="search_country">Search by Country:</label>
            <input type="text" id="search_country" name="search_country" value="<?php echo htmlspecialchars($searchCountry); ?>">
            
            <button type="submit">Search</button>
        </form>

        <?php if ($_SESSION['user_role'] == 'admin'): ?>
            <a href="create_trip.php">Create New Trip</a>
        <?php endif; ?>

        <ul>
            <?php if (count($trips) > 0): ?>
                <?php foreach ($trips as $trip): ?>
                    <li>
                        <h2><?php echo $trip['name']; ?></h2>
                        <p><?php echo $trip['description']; ?></p>
                        <p>Price: <?php echo $trip['price']; ?> USD</p>
                        <p>Available Seats: <?php echo $trip['available_seats']; ?></p>
                        <p>City: <?php echo $trip['city']; ?></p>
                        <p>Country: <?php echo $trip['country']; ?></p>
                        <p>Start Date: <?php echo $trip['start_date']; ?></p>
                        <p>End Date: <?php echo $trip['end_date']; ?></p>
                        <?php if ($_SESSION['user_role'] != 'admin'): ?>
                            <a href="book_trip.php?trip_id=<?php echo $trip['id']; ?>">Book Now</a>
                        <?php endif; ?>
                        <?php if ($_SESSION['user_role'] == 'admin'): ?>
                            <a href="edit_trip.php?trip_id=<?php echo $trip['id']; ?>">Edit</a>
                            <a href="delete_trip.php?trip_id=<?php echo $trip['id']; ?>">Delete</a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No trips found matching your criteria.</li>
            <?php endif; ?>
        </ul>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
