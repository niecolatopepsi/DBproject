<?php
if (session_status() == PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0, // Ciasteczka wygasają po zamknięciu przeglądarki
        'path' => '/',
        'domain' => '',
        'secure' => false, // Ustaw na true, jeśli używasz HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

// Wylogowanie po 30 sekundach bezczynności
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 30)) {
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600); // Usunięcie ciasteczka sesji
    header('Location: login.php');
    exit;
}

$_SESSION['LAST_ACTIVITY'] = time();

$host = 'localhost';
$db = 'travel_app';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database $db :" . $e->getMessage());
}
?>
