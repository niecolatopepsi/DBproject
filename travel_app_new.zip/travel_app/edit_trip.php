<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header('Location: login.php');
    exit;
}

if (isset($_GET['trip_id'])) {
    $trip_id = $_GET['trip_id'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $available_seats = $_POST['available_seats'];
        $city = $_POST['city'];
        $country = $_POST['country'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];

        $stmt = $pdo->prepare("UPDATE trips SET name = ?, description = ?, price = ?, available_seats = ?, city = ?, country = ?, start_date = ?, end_date = ? WHERE id = ?");
        $stmt->execute([$name, $description, $price, $available_seats, $city, $country, $start_date, $end_date, $trip_id]);

        $_SESSION['message'] = "Trip updated successfully.";
        header('Location: trips.php');
        exit;
    } else {
        $stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ?");
        $stmt->execute([$trip_id]);
        $trip = $stmt->fetch();

        include 'views/edit_trip.php';
    }
} else {
    header('Location: trips.php');
    exit;
}
?>
