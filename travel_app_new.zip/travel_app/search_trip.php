<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require 'config.php';

$trips = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $search_city = $_POST['search_city'];
    $search_country = $_POST['search_country'];

    // Przygotowanie warunków zapytania SQL
    $conditions = [];
    $parameters = [];

    if (!empty($search_city)) {
        $conditions[] = 'city LIKE ?';
        $parameters[] = "%$search_city%";
    }

    if (!empty($search_country)) {
        $conditions[] = 'country LIKE ?';
        $parameters[] = "%$search_country%";
    }

    // Budowanie zapytania SQL z warunkami
    $query = "SELECT * FROM trips";
    if (!empty($conditions)) {
        $query .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($parameters);
    $trips = $stmt->fetchAll();
}

include 'views/search_trip.php';
?>
