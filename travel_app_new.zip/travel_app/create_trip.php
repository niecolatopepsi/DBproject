<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $available_seats = $_POST['available_seats'];
    $city = $_POST['city'];
    $country = $_POST['country'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $stmt = $pdo->prepare("INSERT INTO trips (name, description, price, available_seats, city, country, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $price, $available_seats, $city, $country, $start_date, $end_date]);

    $_SESSION['message'] = "New trip created successfully.";
    header('Location: trips.php');
    exit;
}

include 'views/create_trip.php';
?>
