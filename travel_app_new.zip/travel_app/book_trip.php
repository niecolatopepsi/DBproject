<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] == 'admin') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['trip_id'], $_POST['seats'])) {
    $trip_id = $_POST['trip_id'];
    $user_id = $_SESSION['user_id'];
    $seats = (int)$_POST['seats'];
    $reservation_date = date('Y-m-d');

    // Sprawdzenie dostępności miejsc
    $stmt = $pdo->prepare("SELECT available_seats FROM trips WHERE id = ?");
    $stmt->execute([$trip_id]);
    $trip = $stmt->fetch();

    if ($trip && $seats > 0 && $seats <= $trip['available_seats']) {
        // Zaktualizowanie liczby dostępnych miejsc
        $stmt = $pdo->prepare("UPDATE trips SET available_seats = available_seats - ? WHERE id = ?");
        $stmt->execute([$seats, $trip_id]);

        // Dodanie rezerwacji
        $stmt = $pdo->prepare("INSERT INTO reservations (user_id, trip_id, seats, reservation_date) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $trip_id, $seats, $reservation_date]);

        $_SESSION['message'] = "Trip booked successfully.";
        header('Location: reservations.php');
        exit;
    } else {
        $error = "Invalid number of seats selected.";
    }
} else if (isset($_GET['trip_id'])) {
    $trip_id = $_GET['trip_id'];

    $stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ?");
    $stmt->execute([$trip_id]);
    $trip = $stmt->fetch();

    if (!$trip) {
        header('Location: trips.php');
        exit;
    }

    include 'views/book_trip.php';
} else {
    header('Location: trips.php');
    exit;
}
?>
