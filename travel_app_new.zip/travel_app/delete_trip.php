<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header('Location: login.php');
    exit;
}

if (isset($_GET['trip_id'])) {
    $trip_id = $_GET['trip_id'];

    // Przygotowanie zapytania SQL do usunięcia rekordu
    $stmt = $pdo->prepare("DELETE FROM trips WHERE id = ?");
    
    try {
        $stmt->execute([$trip_id]);
        $_SESSION['message'] = 'Trip deleted successfully.';
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Kod błędu dla naruszenia ograniczeń klucza obcego
            $_SESSION['message'] = 'Cannot delete the trip because it is associated with existing reservations.';
        } else {
            $_SESSION['message'] = 'An error occurred while trying to delete the trip.';
        }
    }
}

header('Location: trips.php');
exit;
?>
