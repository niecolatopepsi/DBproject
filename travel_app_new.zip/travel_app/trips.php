<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$searchCity = '';
$searchCountry = '';

if (isset($_GET['search_city']) || isset($_GET['search_country'])) {
    $searchCity = isset($_GET['search_city']) ? $_GET['search_city'] : '';
    $searchCountry = isset($_GET['search_country']) ? $_GET['search_country'] : '';
    
    $query = "SELECT * FROM trips WHERE 1=1";
    $params = [];
    
    if (!empty($searchCity)) {
        $query .= " AND city LIKE ?";
        $params[] = "%$searchCity%";
    }
    
    if (!empty($searchCountry)) {
        $query .= " AND country LIKE ?";
        $params[] = "%$searchCountry%";
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
} else {
    $stmt = $pdo->query("SELECT * FROM trips");
}

$trips = $stmt->fetchAll();

include 'views/trips.php';
?>
