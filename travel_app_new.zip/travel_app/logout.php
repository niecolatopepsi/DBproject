<?php
session_start();
session_unset();
session_destroy();
setcookie(session_name(), '', time() - 3600); // Usunięcie ciasteczka sesji
header('Location: login.php');
?>
