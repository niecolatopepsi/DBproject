<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';
require_once 'core/Database.class.php';
require_once 'core/User.class.php';
require_once 'core/Trip.class.php';
require_once 'core/Reservation.class.php';

use core\Database;
use core\User;
use core\Trip;
use core\Reservation;

$database = new Database();
$db = $database->getConnection();

$login_error = '';
$operation_error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];

    if ($action == 'login') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT * FROM users WHERE name = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && $password == $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            if ($user['role'] == 'admin') {
                header("Location: index.php?action=admin_panel");
            } else {
                header("Location: index.php?action=user_panel");
            }
            exit();
        } else {
            $login_error = "Invalid username or password.";
            header("Location: index.php?action=login&error=" . urlencode($login_error));
            exit();
        }
    } elseif ($action == 'create_user') {
        $user = new User($db);
        $user->name = $_POST['name'];
        $user->email = $_POST['email'];
        $user->password = $_POST['password'];
        $user->role = $_POST['role'];
        if ($user->create()) {
            header("Location: index.php?action=user_manager&message=User+was+created.");
            exit();
        } else {
            $operation_error = "Unable to create user. User with the same name or email already exists.";
            header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'update_user') {
        $user = new User($db);
        $user->id = $_POST['id'];
        $user->name = $_POST['name'];
        $user->email = $_POST['email'];
        if (!empty($_POST['password'])) {
            $user->password = $_POST['password'];
        } else {
            $user_data = $user->read();
            $user->password = $user_data['password'];
        }
        $user->role = $_POST['role'];
        if ($user->update()) {
            header("Location: index.php?action=user_manager&message=User+was+updated.");
            exit();
        } else {
            $operation_error = "Unable to update user.";
            header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'delete_user') {
        $user = new User($db);
        $user->id = $_POST['id'];
        $user_data = $user->read();
        if ($user_data['role'] == 'admin') {
            $operation_error = "Cannot delete admin user.";
        } else {
            if ($user->delete()) {
                header("Location: index.php?action=user_manager&message=User+was+deleted.");
                exit();
            } else {
                $operation_error = "Unable to delete user.";
            }
        }
        header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
        exit();
    } elseif ($action == 'create_trip') {
        $trip = new Trip($db);
        $trip->destination = $_POST['destination'];
        $trip->description = $_POST['description'];
        $trip->price = $_POST['price'];
        $trip->start_date = $_POST['start_date'];
        $trip->end_date = $_POST['end_date'];
        $trip->seats = $_POST['seats'];
        if ($trip->create()) {
            header("Location: index.php?action=trip_manager&message=Trip+was+created.");
            exit();
        } else {
            $operation_error = "Unable to create trip. Trip with the same destination and dates already exists.";
            header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'update_trip') {
        $trip = new Trip($db);
        $trip->id = $_POST['id'];
        $trip->destination = $_POST['destination'];
        $trip->description = $_POST['description'];
        $trip->price = $_POST['price'];
        $trip->start_date = $_POST['start_date'];
        $trip->end_date = $_POST['end_date'];
        $trip->seats = $_POST['seats'];
        if ($trip->update()) {
            header("Location: index.php?action=trip_manager&message=Trip+was+updated.");
            exit();
        } else {
            $operation_error = "Unable to update trip.";
            header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'delete_trip') {
        $trip = new Trip($db);
        $trip->id = $_POST['id'];
        if ($trip->delete()) {
            header("Location: index.php?action=trip_manager&message=Trip+was+deleted.");
            exit();
        } else {
            $operation_error = "Unable to delete trip.";
            header("Location: index.php?action=admin_panel&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'create_reservation') {
        $reservation = new Reservation($db);
        $reservation->user_name = $_POST['user_name'];
        $reservation->trip_destination = $_POST['trip_destination'];
        $reservation->seats = $_POST['seats'];
        try {
            if ($reservation->create()) {
                header("Location: index.php?action=user_panel&message=Reservation+was+created.");
                exit();
            } else {
                $operation_error = "Unable to create reservation.";
                header("Location: index.php?action=reservation_manager&error=" . urlencode($operation_error));
                exit();
            }
        } catch (Exception $e) {
            $operation_error = $e->getMessage();
            header("Location: index.php?action=reservation_manager&error=" . urlencode($operation_error));
            exit();
        }
    } elseif ($action == 'delete_reservation') {
        $reservation = new Reservation($db);
        $reservation->id = $_POST['id'];
        if ($reservation->delete()) {
            header("Location: index.php?action=reservation_manager&message=Reservation+was+deleted.");
            exit();
        } else {
            $operation_error = "Unable to delete reservation.";
            header("Location: index.php?action=reservation_manager&error=" . urlencode($operation_error));
            exit();
        }
    }
}

if ($login_error) {
    echo "<p style='color:red;'>$login_error</p>";
}

if ($operation_error) {
    echo "<p style='color:red;'>$operation_error</p>";
    echo '<br><button onclick="location.href=\'index.php?action=admin_panel\'">Back</button>';
}
?>
