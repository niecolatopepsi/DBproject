<?php
require_once 'config.php';
require_once 'core/Database.class.php';
require_once 'core/User.class.php';
require_once 'core/Trip.class.php';
require_once 'core/Reservation.class.php';
require_once 'core/App.class.php';

use core\App;

session_start();

$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'logout') {
    App::logout();
} elseif ($role == 'admin' || $role == 'user') {
    App::run();
} else {
    App::showLoginPage();
}
?>
