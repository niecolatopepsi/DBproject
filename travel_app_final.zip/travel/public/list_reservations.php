<?php
require_once 'config.php';
require_once 'core/Database.class.php';
require_once 'core/Reservation.class.php';

use core\Database;
use core\Reservation;

$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM reservations";
$stmt = $db->query($query);

echo "<h1>List of Reservations</h1>";
echo "<ul>";
while ($row = $stmt->fetch_assoc()) {
    echo "<li>User: {$row['user_name']}, Trip destination: {$row['trip_destination']}, Reservation date: {$row['reservation_date']}</li>";
}
echo "</ul>";
echo '<br><button onclick="location.href=\'index.php?action=user_panel\'">Back</button>';
?>
