<?php
require_once 'config.php';
require_once 'core/Database.class.php';
require_once 'core/Trip.class.php';

use core\Database;
use core\Trip;

$database = new Database();
$db = $database->getConnection();

$message = isset($_GET['message']) ? $_GET['message'] : '';

if ($message) {
    echo "<p style='color:green;'>$message</p>";
}

$query = "SELECT * FROM trips";
$stmt = $db->query($query);

echo "<h1>List of Trips</h1>";
echo "<ul>";
while ($row = $stmt->fetch_assoc()) {
    echo "<li>{$row['destination']} ({$row['start_date']} - {$row['end_date']}) - Price: {$row['price']} - Seats: {$row['seats']}
    <form action='ctrl.php' method='POST' style='display:inline;'>
        <input type='hidden' name='action' value='delete_trip'>
        <input type='hidden' name='id' value='{$row['id']}'>
        <button type='submit'>Delete</button>
    </form>
    <form action='app/forms/TripEditForm.class.php' method='GET' style='display:inline;'>
        <input type='hidden' name='id' value='{$row['id']}'>
        <button type='submit'>Edit</button>
    </form></li>";
}
echo "</ul>";
echo '<br><button onclick="location.href=\'index.php?action=trip_manager\'">Back</button>';
?>
