<?php
require_once 'config.php';
require_once 'core/Database.class.php';
require_once 'core/Trip.class.php';

use core\Database;
use core\Trip;

$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM trips";
$stmt = $db->query($query);

echo '
<!DOCTYPE html>
<html>
<head>
    <title>List of Trips</title>
</head>
<body>
    <h1>List of Trips</h1>
    <ul>';

while ($row = $stmt->fetch_assoc()) {
    echo "<li>{$row['destination']} ({$row['start_date']} - {$row['end_date']}) - Price: {$row['price']} - Seats: {$row['seats']}
    </li>";
}

echo '</ul>
    <br>
    <button onclick="location.href=\'index.php?action=reservation_manager\'">Back</button>
</body>
</html>';
?>
