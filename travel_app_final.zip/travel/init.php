<?php
// init.php

require_once 'config.php';

$conn = new mysqli($db_config['host'], $db_config['user'], $db_config['password'], $db_config['database']);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Skrypt SQL do stworzenia tabeli `users`
$conn->query("
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `email` VARCHAR(100) NOT NULL,
    `password` VARCHAR(255) NOT NULL
)");

// Skrypt SQL do stworzenia tabeli `trips`
$conn->query("
CREATE TABLE IF NOT EXISTS `trips` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `destination` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `price` DECIMAL(10, 2) NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL
)");

// Skrypt SQL do stworzenia tabeli `reservations`
$conn->query("
CREATE TABLE IF NOT EXISTS `reservations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_name` INT NOT NULL,
    `trip_destination` INT NOT NULL,
    `trip_id` INT NOT NULL,
    `seat` INT NOT NULL,
    `reservation_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_name`) REFERENCES `users`(`name`),
    FOREIGN KEY (`trip_destination`) REFERENCES `trips`(`destination`)
)");

$conn->close();
?>
