<?php
namespace core;

class Reservation {
    private $conn;
    private $table_name = "reservations";

    public $id;
    public $user_name;
    public $trip_destination;
    public $trip_id;
    public $seats;
    public $reservation_date;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        // Get trip ID by trip destination
        $query = "SELECT id FROM trips WHERE destination = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('s', $this->trip_destination);
        $stmt->execute();
        $result = $stmt->get_result();
        $trip = $result->fetch_assoc();

        if (!$trip) {
            throw new \Exception("Trip not found for destination: " . $this->trip_destination);
        }

        $this->trip_id = $trip['id'];

        $query = "INSERT INTO " . $this->table_name . " (user_name, trip_destination, trip_id, seats, reservation_date) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ssii', $this->user_name, $this->trip_destination, $this->trip_id, $this->seats);

        if ($stmt->execute()) {
            // Update the seats in the trips table
            $query = "UPDATE trips SET seats = seats - ? WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $this->seats, $this->trip_id);
            $stmt->execute();

            return true;
        } else {
            return false;
        }
    }

    public function readAll() {
        $query = "SELECT id, user_name, trip_destination, trip_id, seats, reservation_date FROM " . $this->table_name;
        $stmt = $this->conn->query($query);

        $reservations = [];
        while ($row = $stmt->fetch_assoc()) {
            $reservations[] = $row;
        }

        return $reservations;
    }

    public function delete() {
        // Fetch the current reservation to get the trip ID and seats
        $query = "SELECT trip_id, seats FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $this->id);
        $stmt->execute();
        $result = $stmt->get_result();
        $reservation = $result->fetch_assoc();

        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $this->id);

        if ($stmt->execute()) {
            // Update the seats in the trips table
            $query = "UPDATE trips SET seats = seats + ? WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ii', $reservation['seats'], $reservation['trip_id']);
            $stmt->execute();

            return true;
        } else {
            return false;
        }
    }
}
?>
