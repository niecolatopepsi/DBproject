<?php
namespace core;

class Trip {
    private $conn;
    private $table_name = "trips";

    public $id;
    public $destination;
    public $description;
    public $price;
    public $start_date;
    public $end_date;
    public $seats;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET destination=?, description=?, price=?, start_date=?, end_date=?, seats=?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ssdsds', $this->destination, $this->description, $this->price, $this->start_date, $this->end_date, $this->seats);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function readAll() {
        $query = "SELECT id, destination, description, price, start_date, end_date, seats FROM trips";
        $stmt = $this->conn->query($query);

        $trips = [];
        while ($row = $stmt->fetch_assoc()) {
            $trips[] = $row;
        }
        return $trips;
    }


    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $this->id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET destination=?, description=?, price=?, start_date=?, end_date=?, seats=? WHERE id=?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ssdsdsi', $this->destination, $this->description, $this->price, $this->start_date, $this->end_date, $this->seats, $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }
}
?>
