<?php
namespace core;

class App {
    public static function run() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $action = isset($_GET['action']) ? $_GET['action'] : 'login';

        if (!isset($_SESSION['user_id']) && $action !== 'login' && $action !== 'logout') {
            header("Location: index.php?action=login");
            exit();
        }

        switch ($action) {
            case 'login':
                self::showLoginPage();
                break;
            case 'logout':
                self::logout();
                break;
            case 'admin_panel':
                self::showAdminPanel();
                break;
            case 'user_panel':
                self::showUserPanel();
                break;
            case 'user_manager':
                self::showUserManager();
                break;
            case 'trip_manager':
                self::showTripManager();
                break;
            case 'reservation_manager':
                self::showReservationManager();
                break;
            case 'create_user':
                self::createUser();
                break;
            case 'list_users':
                self::listUsers();
                break;
            case 'edit_user':
                self::editUser();
                break;
            case 'create_trip':
                self::createTrip();
                break;
            case 'list_trips':
                self::listTrips();
                break;
            case 'edit_trip':
                self::editTrip();
                break;
            case 'list_user_trips':
                self::listUserTrips();
                break;
            case 'create_reservation':
                self::createReservation();
                break;
            case 'list_reservations':
                self::listReservations();
                break;
            default:
                self::showLoginPage();
        }
    }

    public static function showLoginPage() {
        $smarty = self::getSmarty();
        $logout_message = isset($_GET['logout']) ? 'You have been logged off successfully.' : '';
        $smarty->assign('logout_message', $logout_message);
        $smarty->display('login.tpl');
    }

    public static function showAdminPanel() {
        $smarty = self::getSmarty();
        $smarty->display('admin_panel.tpl');
    }

    public static function showUserPanel() {
        $smarty = self::getSmarty();
        $smarty->display('user_panel.tpl');
    }

    public static function showUserManager() {
        $smarty = self::getSmarty();
        $smarty->display('user_manager.tpl');
    }

    public static function showTripManager() {
        $smarty = self::getSmarty();
        $smarty->display('trip_manager.tpl');
    }

    public static function showReservationManager() {
        $smarty = self::getSmarty();
        $smarty->display('reservation_manager.tpl');
    }

    public static function createUser() {
        $smarty = self::getSmarty();
        $smarty->display('create_user.tpl');
    }

    public static function listUsers() {
        $db = (new Database())->getConnection();
        $user = new User($db);
        $users = $user->readAll();
        $smarty = self::getSmarty();
        $smarty->assign('users', $users);
        $smarty->display('list_users.tpl');
    }

    public static function editUser() {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        if ($id) {
            $db = (new Database())->getConnection();
            $user = new User($db);
            $user->id = $id;
            $user_data = $user->read();
            $smarty = self::getSmarty();
            $smarty->assign('user', $user_data);
            $smarty->display('edit_user.tpl');
        } else {
            header("Location: index.php?action=user_manager");
        }
    }

    public static function createTrip() {
        $smarty = self::getSmarty();
        $smarty->display('create_trip.tpl');
    }

    public static function listTrips() {
        $db = (new Database())->getConnection();
        $trip = new Trip($db);
        $trips = $trip->readAll();
        $smarty = self::getSmarty();
        $smarty->assign('trips', $trips);
        $smarty->display('list_trips.tpl');
    }

    public static function editTrip() {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        if ($id) {
            $db = (new Database())->getConnection();
            $trip = new Trip($db);
            $trip->id = $id;
            $trip_data = $trip->read();
            $smarty = self::getSmarty();
            $smarty->assign('trip', $trip_data);
            $smarty->display('edit_trip.tpl');
        } else {
            header("Location: index.php?action=trip_manager");
        }
    }

    public static function listUserTrips() {
        $db = (new Database())->getConnection();
        $trip = new Trip($db);
        $trips = $trip->readAll();
        $smarty = self::getSmarty();
        $smarty->assign('trips', $trips);
        $smarty->display('list_user_trips.tpl');
    }

    public static function createReservation() {
        $smarty = self::getSmarty();
        $smarty->display('create_reservation.tpl');
    }

    public static function listReservations() {
        $db = (new Database())->getConnection();
        $reservation = new Reservation($db);
        $reservations = $reservation->readAll();
        $smarty = self::getSmarty();
        $smarty->assign('reservations', $reservations);
        $smarty->display('list_reservations.tpl');
    }

    public static function logout() {
        session_unset();
        session_destroy();
        header("Location: index.php?logout=1");
        exit();
    }

    private static function getSmarty() {
        $smarty = new \Smarty();
        $smarty->setTemplateDir(__DIR__ . '/../app/views/templates');
        $smarty->setCompileDir(__DIR__ . '/../app/views/templates_c');
        $smarty->setCacheDir(__DIR__ . '/../app/views/cache');
        $smarty->setConfigDir(__DIR__ . '/../app/views/configs');
        $smarty->assign('base_url', BASE_URL);
        return $smarty;
    }
}
?>
