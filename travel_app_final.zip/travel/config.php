<?php
require_once 'lib/smarty/Smarty.class.php';

define('BASE_URL', '/travel'); // Adjust this path to your application's base URL

$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '',
    'database' => 'travel',
];

// Smarty configuration
$smarty = new Smarty();
$smarty->setTemplateDir(__DIR__ . '/app/views/templates');
$smarty->setCompileDir(__DIR__ . '/app/views/templates_c');
$smarty->assign('base_url', 'http://localhost/travel');

function getSmarty() {
    global $smarty;
    return $smarty;
}
?>
