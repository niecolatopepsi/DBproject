<?php
class UserAddForm {
    public static function render() {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Create User</title>
        </head>
        <body>
            <h1>Create User</h1>
            <form action="ctrl.php" method="POST" autocomplete="off">
                <input type="hidden" name="action" value="create_user">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" required>
                <br>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
                <br>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <br>
                <label for="role">Role:</label>
                <select name="role" id="role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <br>
                <button type="submit">Create User</button>
            </form>
            <br>
            <button onclick="window.history.back();">Back</button>
        </body>
        </html>';
    }
}
?>
