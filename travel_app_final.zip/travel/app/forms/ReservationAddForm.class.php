<?php
class ReservationAddForm {
    public static function render() {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Create Reservation</title>
        </head>
        <body>
            <h1>Create Reservation</h1>
            <form action="ctrl.php" method="POST">
                <input type="hidden" name="action" value="create_reservation">
                <label for="user_name">User Name:</label>
                <input type="text" name="user_name" id="user_name" required>
                <br>
                <label for="trip_destination">Trip Destination:</label>
                <input type="text" name="trip_destination" id="trip_destination" required>
                <br>
                <label for="seats">Seats:</label>
                <input type="number" name="seats" id="seats" required>
                <br>
                <button type="submit">Create Reservation</button>
            </form>
            <br><button onclick="location.href=\'index.php?action=reservation_manager\'">Back</button>
        </body>
        </html>';
    }
}
?>
