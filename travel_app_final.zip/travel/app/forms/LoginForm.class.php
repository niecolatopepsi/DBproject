<?php
class LoginForm {
    public static function render() {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Login</title>
            <link rel="stylesheet" type="text/css" href="{$base_url}/public/css/style.css">
        </head>
        <body>
            <h1>Login</h1>
            <form action="ctrl.php" method="POST" autocomplete="off">
                <input type="hidden" name="action" value="login">
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" required>
                <br>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <br>
                <button type="submit">Login</button>
            </form>
        </body>
        </html>';
    }
}
?>
