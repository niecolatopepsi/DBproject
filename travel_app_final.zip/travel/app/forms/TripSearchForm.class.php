<?php
class TripSearchForm {
    public static function render() {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Search Trips</title>
        </head>
        <body>
            <h1>Search Trips</h1>
            <form action="index.php?action=search_trips_results" method="POST">
                <label for="destination">Destination:</label>
                <input type="text" name="destination" id="destination">
                <br>
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date">
                <br>
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date">
                <br>
                <button type="submit">Search</button>
            </form>
            <br><button onclick="location.href=\'index.php?action=reservation_manager\'">Back</button>
        </body>
        </html>';
    }
}
?>
