<?php
require_once '../../config.php';
require_once '../../core/Database.class.php';
require_once '../../core/User.class.php';

use core\Database;
use core\User;

if (isset($_GET['id'])) {
    $database = new Database();
    $db = $database->getConnection();
    
    $user = new User($db);
    $user->id = $_GET['id'];
    $user_data = $user->read();

    if ($user_data) {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Edit User</title>
        </head>
        <body>
            <h1>Edit User</h1>
            <form action="../../ctrl.php" method="POST" autocomplete="off">
                <input type="hidden" name="action" value="update_user">
                <input type="hidden" name="id" value="'.$user_data['id'].'">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" value="'.$user_data['name'].'" required>
                <br>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="'.$user_data['email'].'" required>
                <br>
                <label for="password">Password (leave blank to keep current):</label>
                <input type="password" name="password" id="password">
                <br>
                <label for="role">Role:</label>
                <select name="role" id="role" required>
                    <option value="user" '.($user_data['role'] == 'user' ? 'selected' : '').'>User</option>
                    <option value="admin" '.($user_data['role'] == 'admin' ? 'selected' : '').'>Admin</option>
                </select>
                <br>
                <button type="submit">Update User</button>
            </form>
            <br>
            <button onclick="window.history.back();">Back</button>
        </body>
        </html>';
    } else {
        echo "User not found.";
    }
}
?>
