<?php
require_once '../../config.php';
require_once '../../core/Database.class.php';
require_once '../../core/Trip.class.php';

use core\Database;
use core\Trip;

if (isset($_GET['id'])) {
    $database = new Database();
    $db = $database->getConnection();
    
    $trip = new Trip($db);
    $trip->id = $_GET['id'];
    $trip_data = $trip->read();

    if ($trip_data) {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Edit Trip</title>
        </head>
        <body>
            <h1>Edit Trip</h1>
            <form action="../../ctrl.php" method="POST" autocomplete="off">
                <input type="hidden" name="action" value="update_trip">
                <input type="hidden" name="id" value="'.$trip_data['id'].'">
                <label for="destination">Destination:</label>
                <input type="text" name="destination" id="destination" value="'.$trip_data['destination'].'" required>
                <br>
                <label for="description">Description:</label>
                <textarea name="description" id="description" required>'.$trip_data['description'].'</textarea>
                <br>
                <label for="price">Price:</label>
                <input type="number" step="0.01" name="price" id="price" value="'.$trip_data['price'].'" required>
                <br>
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" value="'.$trip_data['start_date'].'" required>
                <br>
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date" value="'.$trip_data['end_date'].'" required>
                <br>
                <label for="seats">Seats:</label>
                <input type="number" name="seats" id="seats" value="'.$trip_data['seats'].'" required>
                <br>
                <button type="submit">Update Trip</button>
            </form>
            <br>
            <button onclick="window.history.back();">Back</button>
        </body>
        </html>';
    } else {
        echo "Trip not found.";
    }
}
?>
