<?php
class TripAddForm {
    public static function render() {
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Create Trip</title>
        </head>
        <body>
            <h1>Create Trip</h1>
            <form action="ctrl.php" method="POST">
                <input type="hidden" name="action" value="create_trip">
                <label for="destination">Destination:</label>
                <input type="text" name="destination" id="destination" required>
                <br>
                <label for="description">Description:</label>
                <textarea name="description" id="description" required></textarea>
                <br>
                <label for="price">Price:</label>
                <input type="number" step="0.01" name="price" id="price" required>
                <br>
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" required>
                <br>
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date" required>
                <br>
                <label for="seats">Seats:</label>
                <input type="number" name="seats" id="seats" required>
                <br>
                <button type="submit">Create Trip</button>
            </form>
            <br>
            <button onclick="window.history.back();">Back</button>
        </body>
        </html>';
    }
}
?>
