<?php

namespace app\controllers;

use core\App;
use core\Database;
use core\Utils;

class LoginCtrl {

    private $form;

    public function __construct() {
        $this->form = new \stdClass();
    }

    public function validate() {
        $this->form->login = isset($_POST['username']) ? $_POST['username'] : null;
        $this->form->pass = isset($_POST['password']) ? $_POST['password'] : null;

        if (!isset($this->form->login)) {
            return false;
        }

        if (empty($this->form->login)) {
            Utils::addErrorMessage('Login is required');
        }
        if (empty($this->form->pass)) {
            Utils::addErrorMessage('Password is required');
        }

        if (App::getMessages()->isError()) {
            return false;
        }

        $database = new Database();
        $db = $database->getConnection();

        $query = "SELECT * FROM users WHERE name = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param('s', $this->form->login);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && $this->form->pass == $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            if ($user['role'] == 'admin') {
                header("Location: index.php?action=admin_panel");
            } else {
                header("Location: index.php?action=user_panel");
            }
            exit();
        } else {
            Utils::addErrorMessage('Invalid login or password');
        }

        return !App::getMessages()->isError();
    }

    public function action_login() {
        if ($this->validate()) {
            Utils::addErrorMessage('Successfully logged in');
            App::getRouter()->redirectTo("personList");
        } else {
            $this->generateView();
        }
    }

    public function action_logout() {
        session_destroy();
        header("Location: index.php?logout=1");
        exit();
    }

    public function generateView() {
        $smarty = getSmarty();
        $smarty->assign('form', $this->form);
        $smarty->display('login.tpl');
    }
}
?>
