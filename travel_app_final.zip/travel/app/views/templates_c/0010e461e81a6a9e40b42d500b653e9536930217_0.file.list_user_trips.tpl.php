<?php
/* Smarty version 3.1.30, created on 2024-06-29 17:52:53
  from "D:\Xampp\htdocs\travel\app\views\templates\list_user_trips.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66802dd5578bc2_77885779',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0010e461e81a6a9e40b42d500b653e9536930217' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\list_user_trips.tpl',
      1 => 1719675800,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66802dd5578bc2_77885779 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>List of Trips</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>List of Trips</h1>
        <ul>
            <?php if (count($_smarty_tpl->tpl_vars['trips']->value) > 0) {?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['trips']->value, 'trip');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['trip']->value) {
?>
                    <li>
                        <?php echo $_smarty_tpl->tpl_vars['trip']->value['destination'];?>
 (<?php echo $_smarty_tpl->tpl_vars['trip']->value['price'];?>
) - Seats: <?php echo $_smarty_tpl->tpl_vars['trip']->value['seats'];?>
 - Start: <?php echo $_smarty_tpl->tpl_vars['trip']->value['start_date'];?>
 - End: <?php echo $_smarty_tpl->tpl_vars['trip']->value['end_date'];?>

                        <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/ctrl.php" method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="reserve_trip">
                            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['id'];?>
">
                            <button type="submit">Reserve</button>
                        </form>
                    </li>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            <?php } else { ?>
                <li>No trips found.</li>
            <?php }?>
        </ul>
        <br>
        <button onclick="location.href='<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/index.php?action=user_panel'">Back</button>
    </div>
</body>
</html>
<?php }
}
