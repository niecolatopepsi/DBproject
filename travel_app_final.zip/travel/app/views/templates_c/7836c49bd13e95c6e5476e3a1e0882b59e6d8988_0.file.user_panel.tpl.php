<?php
/* Smarty version 3.1.30, created on 2024-06-29 16:45:06
  from "D:\Xampp\htdocs\travel\app\views\templates\user_panel.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66801df2894316_63969527',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7836c49bd13e95c6e5476e3a1e0882b59e6d8988' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\user_panel.tpl',
      1 => 1719672300,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66801df2894316_63969527 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>User Panel</h1>
        <ul>
            <li><a href="index.php?action=list_reservations">List of Reservations</a></li>
            <li><a href="index.php?action=list_user_trips">List of Trips</a></li>
            <li><a href="index.php?action=create_reservation">Create Reservation</a></li>
        </ul>
        <br>
        <button onclick="location.href='index.php?action=logout'">Logout</button>
        </div>
</body>
</html>
<?php }
}
