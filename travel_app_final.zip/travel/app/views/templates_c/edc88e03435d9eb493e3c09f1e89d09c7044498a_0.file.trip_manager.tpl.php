<?php
/* Smarty version 3.1.30, created on 2024-06-29 14:54:02
  from "D:\Xampp\htdocs\travel\app\views\templates\trip_manager.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_668003ea2b3233_71501404',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'edc88e03435d9eb493e3c09f1e89d09c7044498a' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\trip_manager.tpl',
      1 => 1719665628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_668003ea2b3233_71501404 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Trip Manager</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Trip Manager</h1>
        <ul>
            <li><a href="index.php?action=create_trip">Create Trip</a></li>
            <li><a href="index.php?action=list_trips">List of Trips</a></li>
        </ul>
        <br>
        <button onclick="location.href='index.php?action=admin_panel'">Back</button>
    </div>
</body>
</html>
<?php }
}
