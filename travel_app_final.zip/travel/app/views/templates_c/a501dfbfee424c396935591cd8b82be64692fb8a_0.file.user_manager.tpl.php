<?php
/* Smarty version 3.1.30, created on 2024-06-29 14:53:58
  from "D:\Xampp\htdocs\travel\app\views\templates\user_manager.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_668003e6ab1ac4_04815757',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a501dfbfee424c396935591cd8b82be64692fb8a' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\user_manager.tpl',
      1 => 1719665628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_668003e6ab1ac4_04815757 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Manager</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>User Manager</h1>
        <ul>
            <li><a href="index.php?action=create_user">Create User</a></li>
            <li><a href="index.php?action=list_users">List of Users</a></li>
        </ul>
        <br>
        <button onclick="location.href='index.php?action=admin_panel'">Back</button>
    </div>
</body>
</html>
<?php }
}
