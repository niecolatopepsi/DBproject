<?php
/* Smarty version 3.1.30, created on 2024-06-29 17:54:10
  from "D:\Xampp\htdocs\travel\app\views\templates\list_users.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66802e229c8681_80317728',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b7a27cc70731c909ff0170424e394d359f39e201' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\list_users.tpl',
      1 => 1719675628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66802e229c8681_80317728 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>List of Users</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>List of Users</h1>
        <ul>
            <?php if (count($_smarty_tpl->tpl_vars['users']->value) > 0) {?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
?>
                    <li><?php echo $_smarty_tpl->tpl_vars['user']->value['name'];?>
 (<?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
) - Role: <?php echo $_smarty_tpl->tpl_vars['user']->value['role'];?>

                    <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/ctrl.php" method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="delete_user">
                        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
">
                        <button type="submit">Delete</button>
                    </form>
                    <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/index.php" method="GET" style="display:inline;">
                        <input type="hidden" name="action" value="edit_user">
                        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
">
                        <button type="submit">Edit</button>
                    </form></li>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            <?php } else { ?>
                <li>No users found.</li>
            <?php }?>
        </ul>
        <br>
        <button onclick="location.href='<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/index.php?action=user_manager'">Back</button>
    </div>
</body>
</html>
<?php }
}
