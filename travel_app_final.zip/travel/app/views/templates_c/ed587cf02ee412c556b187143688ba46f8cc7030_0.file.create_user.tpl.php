<?php
/* Smarty version 3.1.30, created on 2024-06-29 14:34:12
  from "D:\Xampp\htdocs\travel\app\views\templates\create_user.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_667fff444ca6a7_08113140',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ed587cf02ee412c556b187143688ba46f8cc7030' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\create_user.tpl',
      1 => 1719664430,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_667fff444ca6a7_08113140 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create User</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Create User</h1>
        <form action="ctrl.php" method="POST" autocomplete="off">
            <input type="hidden" name="action" value="create_user">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>
            <br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br>
            <label for="role">Role:</label>
            <select name="role" id="role" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
            <br>
            <button type="submit">Create User</button>
        </form>
        <br>
        <button onclick="location.href='index.php?action=user_manager'">Back</button>
    </div>
</body>
</html>
<?php }
}
