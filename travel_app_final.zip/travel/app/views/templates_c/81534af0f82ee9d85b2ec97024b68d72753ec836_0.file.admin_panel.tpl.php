<?php
/* Smarty version 3.1.30, created on 2024-06-29 14:53:51
  from "D:\Xampp\htdocs\travel\app\views\templates\admin_panel.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_668003df2c5c11_88132114',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '81534af0f82ee9d85b2ec97024b68d72753ec836' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\admin_panel.tpl',
      1 => 1719665628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_668003df2c5c11_88132114 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Management Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Admin Management Panel</h1>
        <ul>
            <li><a href="index.php?action=user_manager">User Manager</a></li>
            <li><a href="index.php?action=trip_manager">Trip Manager</a></li>
        </ul>
        <br>
        <button onclick="location.href='index.php?action=logout'">Logout</button>
    </div>
</body>
</html>
<?php }
}
