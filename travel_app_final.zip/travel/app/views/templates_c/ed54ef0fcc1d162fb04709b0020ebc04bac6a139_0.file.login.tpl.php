<?php
/* Smarty version 3.1.30, created on 2024-06-29 17:27:49
  from "D:\Xampp\htdocs\travel\app\views\templates\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_668027f57d6ec8_77410163',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ed54ef0fcc1d162fb04709b0020ebc04bac6a139' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\login.tpl',
      1 => 1719674870,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_668027f57d6ec8_77410163 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Travel Application</h1>
        <?php if ($_smarty_tpl->tpl_vars['logout_message']->value) {?>
            <p style="color:green;"><?php echo $_smarty_tpl->tpl_vars['logout_message']->value;?>
</p>
        <?php }?>
        <h2>Login</h2>
        <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/ctrl.php" method="POST" autocomplete="off">
            <input type="hidden" name="action" value="login">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
<?php }
}
