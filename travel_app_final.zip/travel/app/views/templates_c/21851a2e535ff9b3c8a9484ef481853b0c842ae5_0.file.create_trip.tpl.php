<?php
/* Smarty version 3.1.30, created on 2024-06-29 15:50:28
  from "D:\Xampp\htdocs\travel\app\views\templates\create_trip.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66801124cd8392_68651850',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '21851a2e535ff9b3c8a9484ef481853b0c842ae5' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\create_trip.tpl',
      1 => 1719665628,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66801124cd8392_68651850 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Trip</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Create Trip</h1>
        <form action="ctrl.php" method="POST" autocomplete="off">
            <input type="hidden" name="action" value="create_trip">
            <label for="destination">Destination:</label>
            <input type="text" name="destination" id="destination" required>
            <br>
            <label for="description">Description:</label>
            <textarea name="description" id="description" required style="height: 100px; width: 80%; max-width: 300px; border-radius: 5px; padding: 10px; font-size: 16px;"></textarea>
            <br>
            <label for="price">Price:</label>
            <input type="number" step="0.01" name="price" id="price" required>
            <br>
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" id="start_date" required>
            <br>
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" id="end_date" required>
            <br>
            <label for="seats">Seats:</label>
            <input type="number" name="seats" id="seats" required>
            <br>
            <button type="submit">Create Trip</button>
        </form>
        <br>
        <button onclick="location.href='index.php?action=trip_manager'">Back</button>
    </div>
</body>
</html>
<?php }
}
