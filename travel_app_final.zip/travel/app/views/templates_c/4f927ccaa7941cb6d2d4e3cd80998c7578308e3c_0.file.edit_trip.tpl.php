<?php
/* Smarty version 3.1.30, created on 2024-06-29 17:48:06
  from "D:\Xampp\htdocs\travel\app\views\templates\edit_trip.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66802cb6648735_41036876',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f927ccaa7941cb6d2d4e3cd80998c7578308e3c' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\edit_trip.tpl',
      1 => 1719675912,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66802cb6648735_41036876 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Trip</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Trip</h1>
        <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/ctrl.php" method="POST">
            <input type="hidden" name="action" value="update_trip">
            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['id'];?>
">
            <label for="destination">Destination:</label>
            <input type="text" name="destination" id="destination" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['destination'];?>
" required>
            <br>
            <label for="description">Description:</label>
            <textarea name="description" id="description" required><?php echo $_smarty_tpl->tpl_vars['trip']->value['description'];?>
</textarea>
            <br>
            <label for="price">Price:</label>
            <input type="number" step="0.01" name="price" id="price" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['price'];?>
" required>
            <br>
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" id="start_date" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['start_date'];?>
" required>
            <br>
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" id="end_date" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['end_date'];?>
" required>
            <br>
            <label for="seats">Seats:</label>
            <input type="number" name="seats" id="seats" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['seats'];?>
" required>
            <br>
            <button type="submit">Update Trip</button>
        </form>
        <br>
        <button onclick="location.href='<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/index.php?action=trip_manager'">Back</button>
    </div>
</body>
</html>
<?php }
}
