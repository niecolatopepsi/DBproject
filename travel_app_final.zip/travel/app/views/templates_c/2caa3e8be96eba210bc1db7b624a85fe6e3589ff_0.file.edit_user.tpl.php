<?php
/* Smarty version 3.1.30, created on 2024-06-29 17:54:14
  from "D:\Xampp\htdocs\travel\app\views\templates\edit_user.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66802e26ca6476_27769323',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2caa3e8be96eba210bc1db7b624a85fe6e3589ff' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\edit_user.tpl',
      1 => 1719675912,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66802e26ca6476_27769323 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Edit User</h1>
        <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/ctrl.php" method="POST">
            <input type="hidden" name="action" value="update_user">
            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['name'];?>
" required>
            <br>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
" required>
            <br>
            <label for="password">Password (leave blank to keep current):</label>
            <input type="password" name="password" id="password">
            <br>
            <label for="role">Role:</label>
            <select name="role" id="role" required>
                <option value="user" <?php if ($_smarty_tpl->tpl_vars['user']->value['role'] == 'user') {?>selected<?php }?>>User</option>
                <option value="admin" <?php if ($_smarty_tpl->tpl_vars['user']->value['role'] == 'admin') {?>selected<?php }?>>Admin</option>
            </select>
            <br>
            <button type="submit">Update User</button>
        </form>
        <br>
        <button onclick="location.href='<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/index.php?action=user_manager'">Back</button>
    </div>
</body>
</html>
<?php }
}
