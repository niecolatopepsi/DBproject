<?php
/* Smarty version 3.1.30, created on 2024-06-29 16:44:38
  from "D:\Xampp\htdocs\travel\app\views\templates\create_reservation.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_66801dd631d554_59244080',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b33d62d6fa00c78c4d7875fb8f8f7bbebc5981f' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel\\app\\views\\templates\\create_reservation.tpl',
      1 => 1719672212,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66801dd631d554_59244080 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Reservation</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Create Reservation</h1>
        <form action="ctrl.php" method="POST">
            <input type="hidden" name="action" value="create_reservation">
            <label for="user_name">User Name:</label>
            <input type="text" name="user_name" id="user_name" required>
            <br>
            <label for="trip_destination">Trip Destination:</label>
            <input type="text" name="trip_destination" id="trip_destination" required>
            <br>
            <label for="seats">Seats:</label>
            <input type="number" name="seats" id="seats" required>
            <br>
            <button type="submit">Create Reservation</button>
        </form>
        <br>
        <button onclick="location.href='index.php?action=user_panel'">Back</button>
    </div>
</body>
</html>
<?php }
}
