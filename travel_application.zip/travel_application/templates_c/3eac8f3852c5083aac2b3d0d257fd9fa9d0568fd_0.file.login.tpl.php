<?php
/* Smarty version 4.3.4, created on 2024-09-21 14:04:18
  from 'D:\Xampp\htdocs\travel_application\app\views\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eeb6420eb3f0_11342608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3eac8f3852c5083aac2b3d0d257fd9fa9d0568fd' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\login.tpl',
      1 => 1726920236,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eeb6420eb3f0_11342608 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>

    <!-- Display logout message -->
    <?php if ((isset($_smarty_tpl->tpl_vars['logout_message']->value))) {?>
    <p style="color: green;"><?php echo $_smarty_tpl->tpl_vars['logout_message']->value;?>
</p>
    <?php }?>

    <!-- Display error message -->
    <?php if ((isset($_smarty_tpl->tpl_vars['error']->value))) {?>
    <p style="color: red;"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</p>
    <?php }?>

    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'login'),$_smarty_tpl ) );?>
" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>
</body>
</html>
<?php }
}
