<?php
/* Smarty version 4.3.4, created on 2024-09-22 19:44:53
  from 'D:\Xampp\htdocs\travel_application\app\views\userPanel.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66f0579528cb38_02214035',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '47d64130c4605762f751c53e1f6d979a4660c806' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\userPanel.tpl',
      1 => 1726937988,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66f0579528cb38_02214035 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Panel</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>Welcome to the User Panel</h1>
    
    <ul>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'userReservations'),$_smarty_tpl ) );?>
">List of Reservations</a></li>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'userListTrips'),$_smarty_tpl ) );?>
">List of Available Trips</a></li>
    </ul>

    <!-- Logout as a form button -->
    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'logout'),$_smarty_tpl ) );?>
" method="post">
        <button class="logout-button" type="submit">Logout</button>
    </form>
</body>
</html>
<?php }
}
