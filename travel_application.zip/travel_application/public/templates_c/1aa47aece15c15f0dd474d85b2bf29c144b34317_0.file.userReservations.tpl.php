<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:54:27
  from 'D:\Xampp\htdocs\travel_application\app\views\userReservations.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eefa43483347_30554383',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1aa47aece15c15f0dd474d85b2bf29c144b34317' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\userReservations.tpl',
      1 => 1726936604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eefa43483347_30554383 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Xampp\\htdocs\\travel_application\\lib\\smarty\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reservations</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>My Reservations</h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['reservations']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['reservations']->value) > 0) {?>
    <table border="1">
        <thead>
            <tr>
                <th>Destination</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Seats Reserved</th>
                <th>Reservation Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['reservations']->value, 'reservation');
$_smarty_tpl->tpl_vars['reservation']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['reservation']->value) {
$_smarty_tpl->tpl_vars['reservation']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['destination'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['start_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['end_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['reserved_seats'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['reservation_date'];?>
</td>
            </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
    <?php } else { ?>
    <p>No reservations found.</p>
    <?php }?>
    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>

<?php }
}
