<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:36:53
  from 'D:\Xampp\htdocs\travel_application\app\views\userManager.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef625e9bb96_40055428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1e947e00c87875cc658cb653eb07f83caef97465' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\userManager.tpl',
      1 => 1726936604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef625e9bb96_40055428 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Manager</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>User Manager</h1>
    <ul>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'createUser'),$_smarty_tpl ) );?>
">Create User</a></li>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'listUsers'),$_smarty_tpl ) );?>
">List of Users</a></li>
    </ul>
    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>

<?php }
}
