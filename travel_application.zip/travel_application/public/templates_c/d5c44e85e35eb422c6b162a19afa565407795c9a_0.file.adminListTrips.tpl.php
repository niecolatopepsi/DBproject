<?php
/* Smarty version 4.3.4, created on 2024-09-21 19:11:42
  from 'D:\Xampp\htdocs\travel_application\app\views\adminListTrips.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eefe4e1974b0_44514991',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd5c44e85e35eb422c6b162a19afa565407795c9a' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\adminListTrips.tpl',
      1 => 1726938654,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eefe4e1974b0_44514991 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Xampp\\htdocs\\travel_application\\lib\\smarty\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Trips - Admin Panel</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>List of Trips</h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['trips']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['trips']->value) > 0) {?>
    <table border="1">
        <thead>
            <tr>
                <th>Destination</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Price</th>
                <th>Available Seats</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['trips']->value, 'trip');
$_smarty_tpl->tpl_vars['trip']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['trip']->value) {
$_smarty_tpl->tpl_vars['trip']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['trip']->value['destination'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['trip']->value['start_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['trip']->value['end_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['trip']->value['price'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['trip']->value['available_seats'];?>
</td>
                <td>
               
                    <!-- Edit button -->
                    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'editTrip'),$_smarty_tpl ) );?>
" method="get" style="display:inline;">
                        <input type="hidden" name="trip_id" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['trip_id'];?>
">
                        <button type="submit">Edit</button>
                    </form>
                    
                    <!-- Delete trip form -->
                    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'deleteTrip'),$_smarty_tpl ) );?>
" method="post" style="display:inline;">
                        <input type="hidden" name="trip_id" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['trip_id'];?>
">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete this trip?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
    <?php } else { ?>
    <p>No trips available at the moment.</p>
    <?php }?>
    
    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->

</body>
</html>
<?php }
}
