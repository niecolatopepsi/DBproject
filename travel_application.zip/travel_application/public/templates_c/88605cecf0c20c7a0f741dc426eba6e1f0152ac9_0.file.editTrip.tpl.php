<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:27:24
  from 'D:\Xampp\htdocs\travel_application\app\views\editTrip.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef3ec1e4501_15086834',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '88605cecf0c20c7a0f741dc426eba6e1f0152ac9' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\editTrip.tpl',
      1 => 1726935806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef3ec1e4501_15086834 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Trip</title>
</head>
<body>
    <h1>Edit Trip</h1>

    <!-- Display success or error messages -->
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
        <div style="color: green;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>

    <?php if ((isset($_smarty_tpl->tpl_vars['trip']->value))) {?>
    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'updateTrip'),$_smarty_tpl ) );?>
" method="post">
        <input type="hidden" name="trip_id" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['trip_id'];?>
">
        
        <label for="destination">Destination:</label>
        <input type="text" name="destination" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['destination'];?>
" required><br>

        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['start_date'];?>
" required><br>

        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['end_date'];?>
" required><br>

        <label for="price">Price:</label>
        <input type="number" name="price" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['price'];?>
" required><br>

        <label for="available_seats">Available Seats:</label>
        <input type="number" name="available_seats" value="<?php echo $_smarty_tpl->tpl_vars['trip']->value['available_seats'];?>
" required><br>

        <button type="submit">Update Trip</button>
    </form>
    <?php } else { ?>
    <p>No trip found to edit.</p>
    <?php }?>

    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>
<?php }
}
