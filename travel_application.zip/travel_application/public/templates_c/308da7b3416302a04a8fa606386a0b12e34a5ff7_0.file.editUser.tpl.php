<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:21:53
  from 'D:\Xampp\htdocs\travel_application\app\views\editUser.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef2a150d1e4_41814159',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '308da7b3416302a04a8fa606386a0b12e34a5ff7' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\editUser.tpl',
      1 => 1726928014,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef2a150d1e4_41814159 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
</head>
<body>
    <h1>Edit User</h1>

    <!-- Display success or error messages -->
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
        <div style="color: green;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div style="color: red;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>

    <!-- Edit User Form -->
    <?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {?>
    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'updateUser'),$_smarty_tpl ) );?>
" method="post">
        <input type="hidden" name="user_id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['user_id'];?>
">

        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['password'];?>
" required><br> <!-- Plain text password -->

        <button type="submit">Update User</button>
    </form>
    <?php } else { ?>
    <p>No user found to edit.</p>
    <?php }?>

    <p><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'listUsers'),$_smarty_tpl ) );?>
">Back to User List</a></p>
    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>
<?php }
}
