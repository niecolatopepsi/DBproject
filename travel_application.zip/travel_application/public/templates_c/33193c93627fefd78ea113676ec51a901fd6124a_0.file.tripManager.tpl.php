<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:52:44
  from 'D:\Xampp\htdocs\travel_application\app\views\tripManager.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef9dc482ca8_63817011',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33193c93627fefd78ea113676ec51a901fd6124a' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\tripManager.tpl',
      1 => 1726936604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef9dc482ca8_63817011 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trip Manager</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>Trip Manager</h1>
    <ul>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'createTrip'),$_smarty_tpl ) );?>
">Create Trip</a></li>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'adminListTrips'),$_smarty_tpl ) );?>
">List of Trips</a></li>
        <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
    </ul>
</body>
</html>
<?php }
}
