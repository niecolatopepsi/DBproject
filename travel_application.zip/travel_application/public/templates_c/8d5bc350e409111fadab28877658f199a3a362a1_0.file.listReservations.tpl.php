<?php
/* Smarty version 4.3.4, created on 2024-09-21 14:26:32
  from 'D:\Xampp\htdocs\travel_application\app\views\listReservations.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eebb781c0165_70970850',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8d5bc350e409111fadab28877658f199a3a362a1' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\listReservations.tpl',
      1 => 1726919992,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eebb781c0165_70970850 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Xampp\\htdocs\\travel_application\\lib\\smarty\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Reservations</title>
</head>
<body>
    <h1>List of My Reservations</h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['reservations']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['reservations']->value) > 0) {?>
    <table border="1">
        <thead>
            <tr>
                <th>Destination</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Seats Reserved</th>
                <th>Reservation Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['reservations']->value, 'reservation');
$_smarty_tpl->tpl_vars['reservation']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['reservation']->value) {
$_smarty_tpl->tpl_vars['reservation']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['destination'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['start_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['end_date'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['reserved_seats'];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['reservation']->value['reservation_date'];?>
</td>
            </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
    <?php } else { ?>
    <p>No reservations found.</p>
    <?php }?>
</body>
</html>
<?php }
}
