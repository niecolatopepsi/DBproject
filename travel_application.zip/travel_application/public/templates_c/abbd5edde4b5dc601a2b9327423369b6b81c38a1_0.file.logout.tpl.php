<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:38:19
  from 'D:\Xampp\htdocs\travel_application\app\views\logout.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef67be9d6f6_59217384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'abbd5edde4b5dc601a2b9327423369b6b81c38a1' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\logout.tpl',
      1 => 1726936694,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef67be9d6f6_59217384 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>You are logged out.</h1>

    <!-- Display the logout message if it's set -->
    <?php if ((isset($_smarty_tpl->tpl_vars['logout_message']->value))) {?>
    <p style="color: green;"><?php echo $_smarty_tpl->tpl_vars['logout_message']->value;?>
</p>
    <?php }?>

    <!-- Provide a link to go back to the login page -->
    <p><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'login'),$_smarty_tpl ) );?>
">Click here to login again</a></p>
</body>
</html>
<?php }
}
