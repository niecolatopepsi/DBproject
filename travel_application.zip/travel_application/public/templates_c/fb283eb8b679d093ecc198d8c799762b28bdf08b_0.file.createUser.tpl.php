<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:42:05
  from 'D:\Xampp\htdocs\travel_application\app\views\createUser.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eef75d886b62_78413593',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fb283eb8b679d093ecc198d8c799762b28bdf08b' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\createUser.tpl',
      1 => 1726936604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eef75d886b62_78413593 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>Create a New User</h1>

    <!-- Display success or error messages -->
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
        <div style="color: green;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <div style="color: red;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>

    <!-- Create User Form -->
    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'createUser'),$_smarty_tpl ) );?>
" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <button type="submit">Create User</button>
    </form>

    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>
<?php }
}
