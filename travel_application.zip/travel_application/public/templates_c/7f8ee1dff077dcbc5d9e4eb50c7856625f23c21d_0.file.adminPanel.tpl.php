<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:59:53
  from 'D:\Xampp\htdocs\travel_application\app\views\adminPanel.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eefb89056745_54552503',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f8ee1dff077dcbc5d9e4eb50c7856625f23c21d' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\adminPanel.tpl',
      1 => 1726937988,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eefb89056745_54552503 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>Admin Management Panel</h1>
    <ul>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'userManager'),$_smarty_tpl ) );?>
">User Manager</a></li>
        <li><a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'tripManager'),$_smarty_tpl ) );?>
">Trip Manager</a></li>
    </ul>

    <!-- Logout as a form with a button -->
    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'logout'),$_smarty_tpl ) );?>
" method="post">
        <button class="logout-button" type="submit">Logout</button>
    </form>
</body>
</html>
<?php }
}
