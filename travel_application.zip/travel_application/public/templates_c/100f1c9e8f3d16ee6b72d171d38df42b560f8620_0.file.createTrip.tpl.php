<?php
/* Smarty version 4.3.4, created on 2024-09-21 18:53:28
  from 'D:\Xampp\htdocs\travel_application\app\views\createTrip.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66eefa086b1d39_28416602',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '100f1c9e8f3d16ee6b72d171d38df42b560f8620' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\travel_application\\app\\views\\createTrip.tpl',
      1 => 1726937590,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66eefa086b1d39_28416602 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Trip</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<body>
    <h1>Create a New Trip</h1>

    <!-- Display success or error messages -->
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
        <div style="color: green;">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                <p><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
    <?php }?>

    <form action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'createTrip'),$_smarty_tpl ) );?>
" method="post">
        <label for="destination">Destination:</label>
        <input type="text" name="destination" required><br>

        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" required><br>

        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" required><br>

        <label for="price">Price:</label>
        <input type="number" name="price" required><br>

        <label for="available_seats">Available Seats:</label>
        <input type="number" name="available_seats" required><br>

        <button type="submit">Create Trip</button>
    </form>

    <p><button onclick="window.history.back();">Back</button></p> <!-- Back button -->
</body>
</html>
<?php }
}
