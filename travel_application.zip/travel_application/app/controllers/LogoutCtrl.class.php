<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace app\controllers;

use core\App;

/**
 * Description of LogoutCtrl
 *
 * @author Nikola
 */

class LogoutCtrl {
    // Method for handling the logout process
    public function action_logout() {
        // Start the session if it's not already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Set the logout message in the session before destroying it
        $_SESSION['logout_message'] = 'You have successfully logged out.';

        // Destroy the session completely
        session_destroy();

        // Redirect to the logout page to display the message
        header("Location: /travel_application/public/logoutMessage");
        exit();
    }

    // Method to display the logout message
    public function action_logoutMessage() {
        // Start a new session to handle the display of the logout message
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Check if there's a logout message in the session
        if (isset($_SESSION['logout_message'])) {
            App::getSmarty()->assign('logout_message', $_SESSION['logout_message']);
            unset($_SESSION['logout_message']);  // Clear the message after displaying
        }

        // Display the logout page
        App::getSmarty()->display('logout.tpl');
    }
}

