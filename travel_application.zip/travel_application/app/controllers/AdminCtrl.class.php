<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace app\controllers;

use core\App;
use core\ParamUtils;

/**
 * Description of AdminCtrl
 *
 * @author Nikola
 */

class AdminCtrl {

    // Method for displaying the admin panel
    public function action_adminPanel() {
        App::getSmarty()->display('adminPanel.tpl');
    }

    // Method for listing all reservations (admin-only)
    public function action_listAllReservations() {
        // Fetch all reservations for admin
        $reservations = App::getDB()->select("reservations", [
            "[>]users" => ["user_id" => "user_id"],
            "[>]trips" => ["trip_id" => "trip_id"]
        ], [
            "reservations.reservation_date",
            "reservations.reserved_seats",
            "users.username",
            "trips.destination",
            "trips.start_date",
            "trips.end_date"
        ]);

        // Pass reservations data to the view
        App::getSmarty()->assign("reservations", $reservations);
        App::getSmarty()->display('adminReservations.tpl');
    }

    // Trip Manager: Method for listing all trips (admin-only)
    public function action_tripManager() {
        // Fetch all trips from the database
        $trips = App::getDB()->select("trips", "*");

        // Pass trips data to the view
        App::getSmarty()->assign("trips", $trips);
        App::getSmarty()->display('tripManager.tpl');
    }
    
    public function action_adminListTrips() {
        // Fetch all trips
        $trips = App::getDB()->select("trips", "*");

        // Pass trips data to Smarty
        App::getSmarty()->assign("trips", $trips);
        App::getSmarty()->display('adminListTrips.tpl');  // This view will have edit/delete options
    }

    // Trip Manager: Method for creating a new trip (admin-only)
    public function action_createTrip() {
    // Check if the request is POST (form submitted)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Fetch data from the form
        $destination = ParamUtils::getFromPost('destination');
        $startDate = ParamUtils::getFromPost('start_date');
        $endDate = ParamUtils::getFromPost('end_date');
        $price = ParamUtils::getFromPost('price');
        $availableSeats = ParamUtils::getFromPost('available_seats');

        // Validate that all required fields are present
        if ($destination && $startDate && $endDate && $price && $availableSeats) {
            // Insert the new trip into the database
            App::getDB()->insert("trips", [
                "destination" => $destination,
                "start_date" => $startDate,
                "end_date" => $endDate,
                "price" => $price,
                "available_seats" => $availableSeats
            ]);

            // Set a success message
            App::getMessages()->addMessage('Trip created successfully.');

            // Redirect to the list of trips
            App::getRouter()->redirectTo('adminListTrips');
            return;  // Stop further execution
        } else {
            // Set an error message if any required field is missing
            App::getMessages()->addMessage('Error: Please fill in all fields.');
        }
    }

    // If not a POST request, just display the form
    App::getSmarty()->display('createTrip.tpl');
}


    // Trip Manager: Method for editing a trip (admin-only)
    public function action_editTrip() {
        $tripId = ParamUtils::getFromGet('trip_id', true);

        if ($tripId) {
            // Fetch the trip data based on the trip ID
            $trip = App::getDB()->get("trips", "*", [
                "trip_id" => $tripId
            ]);

            if ($trip) {
                // Pass the trip data to the template to display in the form
                App::getSmarty()->assign("trip", $trip);
                App::getSmarty()->display('editTrip.tpl');
            } else {
                App::getMessages()->addMessage('Error: Trip not found.');
                App::getRouter()->redirectTo('adminListTrips');
            }
        } else {
            App::getMessages()->addMessage('Error: Invalid trip ID.');
            App::getRouter()->redirectTo('adminListTrips');
        }
    }
    
    public function action_updateTrip() {
    // Get the form data
    $tripId = ParamUtils::getFromPost('trip_id');
    $destination = ParamUtils::getFromPost('destination');
    $startDate = ParamUtils::getFromPost('start_date');
    $endDate = ParamUtils::getFromPost('end_date');
    $price = ParamUtils::getFromPost('price');
    $availableSeats = ParamUtils::getFromPost('available_seats');

    // Validate and update the trip in the database
    if ($tripId && $destination && $startDate && $endDate && $price && $availableSeats) {
        // Perform the update
        App::getDB()->update("trips", [
            "destination" => $destination,
            "start_date" => $startDate,
            "end_date" => $endDate,
            "price" => $price,
            "available_seats" => $availableSeats
        ], [
            "trip_id" => $tripId
        ]);

        // Set a success message
        App::getMessages()->addMessage('Trip updated successfully.');

        // Redirect back to the list of trips with the success message
        App::getRouter()->redirectTo('adminListTrips');
    } else {
        // Set an error message if validation fails
        App::getMessages()->addMessage('Error: Please fill in all fields.');

        // Redirect back to the same edit form with the trip_id in the URL
        App::getRouter()->redirectTo('editTrip/'.$tripId);
    }
}

    // Trip Manager: Method for deleting a trip (admin-only)
    public function action_deleteTrip() {
        // Get trip_id from form
        $tripId = ParamUtils::getFromPost('trip_id');

        // Delete the trip from the database
        if ($tripId) {
            App::getDB()->delete("trips", [
                "trip_id" => $tripId
            ]);
        }

        // Redirect back to the trip manager
        App::getRouter()->redirectTo('adminListTrips');
    }
    
    public function action_userManager() {
    // Fetch all users
    $users = App::getDB()->select("users", "*");

    // Pass users data to Smarty
    App::getSmarty()->assign("users", $users);
    App::getSmarty()->display('userManager.tpl');
}

    // User Manager: Method for listing all users (admin-only)
    public function action_listUsers() {
        // Fetch all users from the database
        $users = App::getDB()->select("users", "*");

        // Pass users data to the view
        App::getSmarty()->assign("users", $users);
        App::getSmarty()->display('listUsers.tpl');
    }

    // User Manager: Method for creating a new user (admin-only)
    public function action_createUser() {
        // Fetch data from form
        $username = ParamUtils::getFromPost('username');
        $email = ParamUtils::getFromPost('email');
        $password = ParamUtils::getFromPost('password');

        // Validate and insert user into the database
        if ($username && $email && $password) {
            App::getDB()->insert("users", [
                "username" => $username,
                "email" => $email,
                "password" => $password  // In production, hash the password
            ]);
            App::getRouter()->redirectTo('listUsers');
        } else {
            App::getSmarty()->assign('error', 'Please fill in all fields.');
            App::getSmarty()->display('createUser.tpl');
        }
    }

    // User Manager: Method for editing a user (admin-only)
    public function action_editUser() {
    $userId = ParamUtils::getFromGet('user_id', true);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle form submission (update user)
        $username = ParamUtils::getFromPost('username');
        $email = ParamUtils::getFromPost('email');
        $password = ParamUtils::getFromPost('password');

        if ($username && $email && $password) {
            // Update user in the database
            App::getDB()->update("users", [
                "username" => $username,
                "email" => $email,
                "password" => $password  // Hash the password in production
            ], [
                "user_id" => $userId
            ]);

            // Set success message and redirect to the user list
            App::getMessages()->addMessage('User updated successfully.');
            App::getRouter()->redirectTo('listUsers');
        } else {
            // Set error message if fields are missing
            App::getMessages()->addMessage('Error: Please fill in all fields.');
            App::getRouter()->redirectTo('editUser/'.$userId);
        }
    } else {
        // Display the edit form with current user details
        $user = App::getDB()->get("users", "*", ["user_id" => $userId]);

        if ($user) {
            App::getSmarty()->assign("user", $user);
            App::getSmarty()->display('editUser.tpl');
        } else {
            App::getMessages()->addMessage('Error: User not found.');
            App::getRouter()->redirectTo('listUsers');
        }
    }
}

public function action_updateUser() {
    // Get the user ID from the hidden input field
    $userId = ParamUtils::getFromPost('user_id');

    // Get the updated form data
    $username = ParamUtils::getFromPost('username');
    $email = ParamUtils::getFromPost('email');
    $password = ParamUtils::getFromPost('password');

    // Check if all fields are filled in
    if ($userId && $username && $email && $password) {
        // Hash the password (ensure it's secure)

        // Perform the database update
        App::getDB()->update("users", [
            "username" => $username,
            "email" => $email,
            "password" => $password
        ], [
            "user_id" => $userId
        ]);

        // Set success message and redirect to the list of users
        App::getMessages()->addMessage('User updated successfully.');
        App::getRouter()->redirectTo('listUsers');
    } else {
        // If any field is missing, return an error message
        App::getMessages()->addMessage('Error: Please fill in all fields.');
        App::getRouter()->redirectTo('editUser/'.$userId);
    }
}



    // User Manager: Method for deleting a user (admin-only)
    public function action_deleteUser() {
    // Get the user ID from the form submission or URL
    $userId = ParamUtils::getFromPost('user_id'); // From a form, or use ParamUtils::getFromCleanURL(1) if passed via URL

    if ($userId) {
        // Perform the delete operation
        $result = App::getDB()->delete("users", [
            "user_id" => $userId
        ]);

        // Check if a row was affected (i.e., the user was actually deleted)
        if ($result->rowCount() > 0) {
            // Set a success message and redirect to the list of users
            App::getMessages()->addMessage('User deleted successfully.');
        } else {
            // If no rows were deleted, show an error message
            App::getMessages()->addMessage('Error: User not found or could not be deleted.');
        }
    } else {
        // If no user ID was provided, show an error message
        App::getMessages()->addMessage('Error: No user ID provided.');
    }

    // Redirect to the list of users
    App::getRouter()->redirectTo('listUsers');
}
}
