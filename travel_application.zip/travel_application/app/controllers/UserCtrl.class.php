<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace app\controllers;

use core\App;
use core\ParamUtils;

/**
 * Description of UserCtrl
 *
 * @author Nikola
 */

class UserCtrl {
    // Method to display the user panel
    public function action_userPanel() {
        App::getSmarty()->display('userPanel.tpl');
    }

    // Method to list the user's reservations
    public function action_userReservations() {
        // Check if the user ID exists in the session
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];  // Get the user ID from the session

            // Fetch the user's reservations from the database
            $reservations = App::getDB()->select("reservations", [
                "[>]trips" => ["trip_id" => "trip_id"]
            ], [
                "reservations.reservation_date",
                "reservations.reserved_seats",
                "trips.destination",
                "trips.start_date",
                "trips.end_date"
            ], [
                "reservations.user_id" => $userId
            ]);

            // Pass the reservations to the template
            App::getSmarty()->assign("reservations", $reservations);
        } else {
            // If no user ID in session, assign an error message
            App::getSmarty()->assign('error', 'User is not logged in.');
        }

        // Display the reservations list template
        App::getSmarty()->display('userReservations.tpl');
    }

    // Method to list available trips for the user
    public function action_userListTrips() {
        // Fetch all available trips from the database
        $trips = App::getDB()->select("trips", "*");

        // Pass the trips to the Smarty template
        App::getSmarty()->assign("trips", $trips);
        App::getSmarty()->display('userListTrips.tpl');
    }

    // Method to handle user logout
    public function action_logout() {
        // Unset user session data and destroy session
        session_unset();
        session_destroy();

        // Redirect to the login page
        App::getRouter()->redirectTo('login');
    }

    // Method for reserving a trip
    public function action_reserveTrip() {
    // Get the trip ID and the number of seats to reserve from the form
    $tripId = ParamUtils::getFromPost('trip_id');
    $reservedSeats = ParamUtils::getFromPost('reserved_seats');
    $userId = \core\SessionUtils::load("user_id", true); // Assuming the user ID is stored in session after login

    // Ensure valid input
    if (empty($tripId) || empty($reservedSeats) || $reservedSeats <= 0) {
        App::getMessages()->addMessage('Error: Invalid trip or number of seats.');
        App::getRouter()->redirectTo('listTrips');
        return;
    }

    // Fetch the trip details to check available seats
    $trip = App::getDB()->get("trips", "*", ["trip_id" => $tripId]);

    // Check if the trip exists and there are enough available seats
    if ($trip && $reservedSeats <= $trip['available_seats']) {
        // Start a transaction to ensure consistency
        App::getDB()->pdo->beginTransaction();

        try {
            // Step 1: Update the available seats in the trips table
            $newAvailableSeats = $trip['available_seats'] - $reservedSeats;

            $updateResult = App::getDB()->update("trips", [
                "available_seats" => $newAvailableSeats
            ], [
                "trip_id" => $tripId
            ]);

            if ($updateResult->rowCount() === 0) {
                throw new Exception('Failed to update available seats.');
            }

            // Step 2: Insert a new reservation into the reservations table
            $insertResult = App::getDB()->insert("reservations", [
                "user_id" => $userId,
                "trip_id" => $tripId,
                "reserved_seats" => $reservedSeats,
                "reservation_date" => date('Y-m-d H:i:s')
            ]);

            if (!$insertResult) {
                throw new Exception('Failed to insert reservation.');
            }

            // Get the reservation_id of the newly inserted reservation
            $reservationId = App::getDB()->id(); // This fetches the last inserted reservation_id

            // Commit the transaction
            App::getDB()->pdo->commit();

            // Set a success message including the reservation ID
            App::getMessages()->addMessage("Trip reserved successfully. Reservation ID: {$reservationId}");

        } catch (Exception $e) {
            // Rollback transaction if any failure occurs
            App::getDB()->pdo->rollBack();
            App::getMessages()->addMessage('Error: ' . $e->getMessage());
        }

        // Redirect to the list of trips
        App::getRouter()->redirectTo('userListTrips');
    } else {
        // Set an error message if there are not enough seats or the trip doesn't exist
        App::getMessages()->addMessage('Error: Not enough available seats.');
        App::getRouter()->redirectTo('userListTrips');
    }
}

}
