<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace app\controllers;

use core\App;
use core\RoleUtils;
use core\ParamUtils;

/**
 * Description of LoginCtrl
 *
 * @author Nikola
 */

class LoginCtrl {
    // Method for handling the login process
    public function action_login() {
        // Start the session if it's not already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Check if the form was submitted
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Get login credentials from POST request
            $username = ParamUtils::getFromPost('username');
            $password = ParamUtils::getFromPost('password');

            // Validate the user (replace this with actual database validation)
            $user = App::getDB()->get("users", "*", [
                "username" => $username,
                "password" => $password  // In production, use hashed passwords
            ]);

            if ($user) {
                // Login successful: Store the user ID and role in the session
                $_SESSION['user_id'] = $user['user_id'];  // Set user ID in session
                $_SESSION['username'] = $user['username']; // Store the username
                
                // Check if the user is an admin or regular user
                if ($user['username'] === 'admin') {
                    RoleUtils::addRole('admin');  // Add 'admin' role to session
                    App::getRouter()->redirectTo('adminPanel');  // Redirect to admin panel
                } else {
                    RoleUtils::addRole('user');  // Add 'user' role to session
                    App::getRouter()->redirectTo('userPanel');  // Redirect to user panel
                }
            } else {
                // Login failed: Assign an error message
                App::getSmarty()->assign('error', 'Invalid username or password');
            }
        }

        // Display the login form
        App::getSmarty()->display('login.tpl');
    }

    // Method for handling logout
    public function action_logout() {
        // Start the session if it's not already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Set the logout message in the session before destroying it
        $_SESSION['logout_message'] = 'You have successfully logged out.';

        // Destroy the session completely
        session_destroy();

        // Redirect to a static logout page without restarting the session
        header("Location: /travel_application/public/logout");
        exit();
    }

    // Method for displaying the logout page with the logout message
    public function action_logoutPage() {
        // Start session only if it exists (it will be a new session after logout)
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Check if there's a logout message in the session
        if (isset($_SESSION['logout_message'])) {
            App::getSmarty()->assign('logout_message', $_SESSION['logout_message']);
            unset($_SESSION['logout_message']);  // Clear the message after displaying
        }

        // Display the logout page
        App::getSmarty()->display('logout.tpl');
    }
}
