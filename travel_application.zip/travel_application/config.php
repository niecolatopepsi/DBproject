<?php

$conf->debug = true; # Set to true for development (displays more error details)

# ---- Webapp location
$conf->server_name = 'localhost';   # Server address
$conf->protocol = 'http';           # http or https
$conf->app_root = '/travel_application/public';   # Project root folder in the domain

# ---- Database config - values required by Medoo
$conf->db_type = 'mysql';           # Database type
$conf->db_server = 'localhost';     # Database server address
$conf->db_name = 'travel_db';       # Database name
$conf->db_user = 'root';            # Database username (update accordingly)
$conf->db_pass = '';                # Database password (update accordingly)
$conf->db_charset = 'utf8';         # Character encoding

# ---- Database config - optional values
$conf->db_port = '3306';
#$conf->db_prefix = '';
$conf->db_option = [ PDO::ATTR_CASE => PDO::CASE_NATURAL, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ];