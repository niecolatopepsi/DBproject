<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('login'); 

// Public Routes
Utils::addRoute('login', 'LoginCtrl');
Utils::addRoute('logout', 'LogoutCtrl');
Utils::addRoute('logoutMessage', 'LogoutCtrl'); 
// Admin Routes
Utils::addRoute('adminPanel', 'AdminCtrl', ['admin']);
Utils::addRoute('userManager', 'AdminCtrl', ['admin']);
Utils::addRoute('createUser', 'AdminCtrl', ['admin']);
Utils::addRoute('listUsers', 'AdminCtrl', ['admin']);
Utils::addRoute('editUser', 'AdminCtrl', ['admin']);
Utils::addRoute('updateUser', 'AdminCtrl', ['admin']);
Utils::addRoute('deleteUser', 'AdminCtrl', ['admin']);
Utils::addRoute('tripManager', 'AdminCtrl', ['admin']);
Utils::addRoute('createTrip', 'AdminCtrl', ['admin']);
Utils::addRoute('adminListTrips', 'AdminCtrl', ['admin']);
Utils::addRoute('editTrip', 'AdminCtrl', ['admin']);
Utils::addRoute('updateTrip', 'AdminCtrl', ['admin']);
Utils::addRoute('deleteTrip', 'AdminCtrl', ['admin']);
Utils::addRoute('adminReservations', 'AdminCtrl', ['admin']);  

// User Routes
Utils::addRoute('userPanel', 'UserCtrl', ['user']);
Utils::addRoute('userReservations', 'UserCtrl', ['user']);
Utils::addRoute('userListTrips', 'UserCtrl', ['user']);
Utils::addRoute('reserveTrip', 'UserCtrl', ['user']);
