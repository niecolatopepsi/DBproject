<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $available_seats = $_POST['available_seats'];

    $stmt = $pdo->prepare("INSERT INTO trips (name, description, price, available_seats) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $description, $price, $available_seats]);

    header('Location: trips.php');
}

include 'views/create_trip.php';
?>
