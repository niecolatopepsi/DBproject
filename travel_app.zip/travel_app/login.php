<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ustalona nazwa użytkownika i hasło dla administratora
    if ($username === 'admin' && $password === 'admin') {
        $_SESSION['user_id'] = 'admin';
        header('Location: trips.php');
    } else {
        $error = 'Invalid credentials';
    }
}

include 'views/login.php';
?>
