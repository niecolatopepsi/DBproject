<!DOCTYPE html>
<html>
<head>
    <title>Trips</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Trips</h1>
    <a href="create_trip.php">Create New Trip</a>
    <ul>
        <?php foreach ($trips as $trip): ?>
            <li>
                <h2><?php echo $trip['name']; ?></h2>
                <p><?php echo $trip['description']; ?></p>
                <p>Price: <?php echo $trip['price']; ?> USD</p>
                <p>Available Seats: <?php echo $trip['available_seats']; ?></p>
                <a href="book_trip.php?trip_id=<?php echo $trip['id']; ?>">Book Now</a>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="logout.php">Logout</a>
</body>
</html>
