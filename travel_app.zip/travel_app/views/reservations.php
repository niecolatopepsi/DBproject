<!DOCTYPE html>
<html>
<head>
    <title>My Reservations</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>My Reservations</h1>
    <ul>
        <?php foreach ($reservations as $reservation): ?>
            <li>
                <h2><?php echo $reservation['name']; ?></h2>
                <p><?php echo $reservation['description']; ?></p>
                <p>Price: <?php echo $reservation['price']; ?> USD</p>
                <p>Reservation Date: <?php echo $reservation['reservation_date']; ?></p>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="trips.php">Back to Trips</a>
    <a href="logout.php">Logout</a>
</body>
</html>
