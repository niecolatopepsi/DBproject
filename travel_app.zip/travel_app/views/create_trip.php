<!DOCTYPE html>
<html>
<head>
    <title>Create New Trip</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Create New Trip</h1>
    <form action="create_trip.php" method="POST">
        <label>Name</label>
        <input type="text" name="name" required>
        <label>Description</label>
        <textarea name="description" required></textarea>
        <label>Price</label>
        <input type="text" name="price" required>
        <label>Available Seats</label>
        <input type="number" name="available_seats" required>
        <button type="submit">Create Trip</button>
    </form>
</body>
</html>
