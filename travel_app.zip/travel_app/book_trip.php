<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['trip_id'])) {
    $trip_id = $_GET['trip_id'];
    $user_id = $_SESSION['user_id'];
    $reservation_date = date('Y-m-d');

    $stmt = $pdo->prepare("INSERT INTO reservations (user_id, trip_id, reservation_date) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $trip_id, $reservation_date]);

    header('Location: reservations.php');
}
?>
