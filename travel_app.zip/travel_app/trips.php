<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query("SELECT * FROM trips");
$trips = $stmt->fetchAll();

include 'views/trips.php';
?>
